﻿// File: Services/ExternalUserService.cs

using System.Net.Http;
using System.Net.Http.Json;
using RaftLabs.UserService.Models;
using RaftLabs.UserService.Interfaces;
using RaftLabs.UserService.Configuration;

namespace RaftLabs.UserService.Services;

public class ExternalUserService : IExternalUserService
{
    private readonly HttpClient _httpClient;
    private readonly string _baseUrl;

    public ExternalUserService(HttpClient httpClient, ApiSettings settings)
    {
        _httpClient = httpClient;
        _baseUrl = settings.BaseUrl.TrimEnd('/');

        // Set default API key header if configured
        if (!string.IsNullOrWhiteSpace(settings.ApiKey))
        {
            _httpClient.DefaultRequestHeaders.Remove("x-api-key");
            _httpClient.DefaultRequestHeaders.Add("x-api-key", settings.ApiKey);
        }
    }

    public async Task<User?> GetUserByIdAsync(int userId)
    {
        try
        {
            var response = await _httpClient.GetAsync($"{_baseUrl}/users/{userId}");

            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return null;

                throw new HttpRequestException($"Failed to fetch user. Status code: {response.StatusCode}");
            }

            var json = await response.Content.ReadFromJsonAsync<Dictionary<string, User>>();
            return json?["data"];
        }
        catch (Exception ex)
        {
            throw new ApplicationException($"Error fetching user: {ex.Message}", ex);
        }
    }

    public async Task<IEnumerable<User>> GetAllUsersAsync()
    {
        var allUsers = new List<User>();
        int page = 1;

        try
        {
            while (true)
            {
                var response = await _httpClient.GetAsync($"{_baseUrl}/users?page={page}");
                if (!response.IsSuccessStatusCode)
                    throw new HttpRequestException($"Failed to fetch users. Status code: {response.StatusCode}");

                var data = await response.Content.ReadFromJsonAsync<ApiResponse<User>>();
                if (data == null || data.Data.Count == 0)
                    break;

                allUsers.AddRange(data.Data);

                if (page >= data.Total_Pages) break;
                page++;
            }
        }
        catch (Exception ex)
        {
            throw new ApplicationException($"Error fetching users: {ex.Message}", ex);
        }

        return allUsers;
    }
}
