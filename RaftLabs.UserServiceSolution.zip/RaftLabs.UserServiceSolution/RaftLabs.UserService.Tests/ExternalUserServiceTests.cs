﻿using RaftLabs.UserService.Configuration;
using RaftLabs.UserService.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RaftLabs.UserService.Tests
{
    public class ExternalUserServiceTests
    {
        [Fact]
        public async Task GetUserByIdAsync_ReturnsUser()
        {
            var userJson = """
        { "data": { "id": 1, "email": "test@example.com", "first_name": "Test", "last_name": "User", "avatar": "" } }
        """;

            var handler = new MockHttpMessageHandler(userJson, HttpStatusCode.OK);
            var client = new HttpClient(handler);
            var settings = new ApiSettings { BaseUrl = "https://reqres.in/api" };
            var service = new ExternalUserService(client, settings);

            var user = await service.GetUserByIdAsync(1);

            Assert.NotNull(user);
            Assert.Equal("test@example.com", user?.Email);
        }

        [Fact]
        public async Task GetAllUsersAsync_ReturnsAllUsers()
        {
            var page1 = """
        {
            "page":1, "per_page":2, "total":3, "total_pages":2,
            "data":[{"id":1,"email":"a@b.com","first_name":"A","last_name":"B","avatar":""}]
        }
        """;
            var page2 = """
        {
            "page":2, "per_page":2, "total":3, "total_pages":2,
            "data":[{"id":2,"email":"c@d.com","first_name":"C","last_name":"D","avatar":""}]
        }
        """;

            var handler = new MultiPageMockHandler(new[] { page1, page2 });
            var client = new HttpClient(handler);
            var settings = new ApiSettings { BaseUrl = "https://reqres.in/api" };
            var service = new ExternalUserService(client, settings);

            var users = (await service.GetAllUsersAsync()).ToList();

            Assert.Equal(2, users.Count);
            Assert.Equal("a@b.com", users[0].Email);
            Assert.Equal("c@d.com", users[1].Email);
        }
    }

    // Supporting Handlers
    public class MockHttpMessageHandler : HttpMessageHandler
    {
        private readonly string _json;
        private readonly HttpStatusCode _status;

        public MockHttpMessageHandler(string json, HttpStatusCode status)
        {
            _json = json;
            _status = status;
        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken) =>
            Task.FromResult(new HttpResponseMessage(_status) { Content = new StringContent(_json) });
    }

    public class MultiPageMockHandler : HttpMessageHandler
    {
        private readonly Queue<string> _responses;

        public MultiPageMockHandler(IEnumerable<string> responses) => _responses = new Queue<string>(responses);

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var content = _responses.Count > 0 ? _responses.Dequeue() : "{}";
            return Task.FromResult(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(content) });
        }
    }
}
