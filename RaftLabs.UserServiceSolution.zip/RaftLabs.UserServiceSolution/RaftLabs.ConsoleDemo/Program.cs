﻿using Microsoft.Extensions.Configuration;
using RaftLabs.UserService.Configuration;
using RaftLabs.UserService.Services;

var config = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json")
    .Build();

var settings = config.GetSection("ApiSettings").Get<ApiSettings>();
var httpClient = new HttpClient();

var service = new ExternalUserService(httpClient, settings);
var user = await service.GetUserByIdAsync(1);
Console.WriteLine($"{user?.FirstName} {user?.LastName}");